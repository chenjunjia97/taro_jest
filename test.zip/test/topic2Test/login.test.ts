import { setupServer } from 'msw/node'
import { rest } from 'msw'
import { request } from '@tarojs/taro'
import * as taro from '@tarojs/taro'
// import { interceptor } from '../../src/utils/request'


console.log(taro.request, 'jjjjjjjj')
const mockLogin = () => request({
    url: '/mockLogin',
    method: 'GET'
})


const worker = setupServer(
    rest.get('/mockLogin', (_, res, ctx) => {
        return res(ctx.json({greeting: 'hello there'}))
    }),
)

beforeAll(() => {
    worker.listen()
})
afterEach(() => {
    worker.resetHandlers()
})
afterAll(() => {
    worker.close()
})

describe('测试登陆逻辑', () => {

    test('测试拦截器效果', () => {
        mockLogin().then((data) => {
            expect(data.data.greeting).toEqual('hello there')
        })
    })
})