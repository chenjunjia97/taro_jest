module.exports = {
  process() {
    return ''
  }
}
